# 🚀 DEPLOY NOW - Beam Affiliate Platform

## Quick Steps:

### 1. Backend Deployment (Render.com)
1. Go to https://render.com
2. Sign up (free)
3. Click "New +" → "Web Service"
4. Upload the `backend` folder
5. Use these settings:
   - Build Command: `npm install`
   - Start Command: `npm start`
   - Environment: Node
6. Add environment variables from `.env.example`
7. Deploy!

### 2. Frontend Deployment (Render.com)
1. In Render dashboard, click "New +" → "Static Site"
2. Upload the `frontend` folder
3. Use these settings:
   - Build Command: `npm install && npm run build`
   - Publish Directory: `build`
4. Add environment variables from `.env.example`
5. Deploy!

### 3. Database Setup (MongoDB Atlas)
1. Go to https://mongodb.com/atlas
2. Create free account
3. Create new cluster
4. Get connection string
5. Update MONGODB_URI in backend environment variables

### 4. Update URLs
1. Get your actual Render URLs
2. Update FRONTEND_URL in backend
3. Update REACT_APP_API_URL in frontend
4. Redeploy both services

## Test Your System:
1. Register as reseller
2. Get affiliate links
3. Test click tracking
4. Create test sales
5. View dashboard analytics

Your app will be live in ~15 minutes!
